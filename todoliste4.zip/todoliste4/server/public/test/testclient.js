import * as api from './api.js';

const output = document.getElementById('output');

async function runTest() {
  log('Starting Test');
  log("List of Users: " + JSON.stringify(await api.getUsers()));
  log("List of Users: " + JSON.stringify(await api.createUsers(10,"Hey")));
  log("User with ID #4: " + JSON.stringify(await api.getUserByID(4)));
  log("Patched User: " + JSON.stringify(await api.patchUserByID(4)));
  log("After deleting: " + JSON.stringify(await api.deleteUserByID(2)));
  log("List of Specific User: " + JSON.stringify(await api.getListofUser(0)));
  log("List of Specific User: " + JSON.stringify(await api.postList(0,"Johnny")));
  log("List Specific List: " + JSON.stringify(await api.getListByID(0,0)));
  log("Patch Specific List: " + JSON.stringify(await api.patchListByID(0,0)));
  log("Delete Specific List: " + JSON.stringify(await api.deleteListByID(0,4)));
  log("List Tasks: " + JSON.stringify(await api.getTasks(0,0)));
  log("List Tasks: " + JSON.stringify(await api.postTasks(0,0)));
  log("List Task by ID: " + JSON.stringify(await api.getTaskByID(0,0,7)));
  log("Patch Task by ID: " + JSON.stringify(await api.patchTaskByID(0,0,7)));
  log("Delete Task by ID: " + JSON.stringify(await api.deleteTaskByID(0,0,6)));
  log("Multiuser Status: " + JSON.stringify(await api.getMultiUser()));
  log("Max IDs Status: " + JSON.stringify(await api.getMaxIDs()));
}

function log(text) {
  let p = document.createElement('li')
  p.innerText = text
  output.appendChild(p)
}

runTest()
