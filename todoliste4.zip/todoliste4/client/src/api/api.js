const baseUrl = 'http://127.0.0.1:3000/api/';

export async function getUsers() {
    const res = await fetch(baseUrl + 'users/', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const json = await res.json();
    return json;
}

export async function createUsers(new_user) {
    const res = await fetch(baseUrl + 'users/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(new_user)
    });
    const json = await res.json();
    return json;
}

export async function getUserByID(userID) {
    //alert(baseUrl + 'users/' + userID)
    const res = await fetch(baseUrl + 'users/' + userID, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    //const json = "error";
    //try{
        const json = await res.json();
        //alert("OK")
    //}
    //catch(e){
        //alert(json)
    //}
    return json;
}

export async function patchUserByID(tuserID) {
    let new_user = {test: true, user: "Geronimo", userID: 500};
    const res = await fetch(baseUrl + 'users/' + tuserID, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(new_user)
    });
    const json = await res.json();
    return json;
}

export async function deleteUserByID(userID) {
    const res = await fetch(baseUrl + 'users/' + userID, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const json = await res.json();
    return json;
}

export async function getListofUser(userID) {
    const res = await fetch(baseUrl + 'users/' + userID + '/lists/', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const json = await res.json();
    return json;
}

export async function postList(userID, new_list) {
    const res = await fetch(baseUrl + 'users/' + userID + '/lists/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(new_list)
    });
    const json = await res.json();
    return json;
}

export async function getListByID(userID, listID) {
    const res = await fetch(baseUrl + 'users/' + userID + '/lists/' + listID, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const json = await res.json();
    return json;
}

export async function patchListByID(userID, listID) {
    let patch_list = {test: true, nexttest: false, listID: 100, name: "Badabing"};
    const res = await fetch(baseUrl + 'users/' + userID + '/lists/' + listID, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(patch_list)
    });
    const json = await res.json();
    return json;
}

export async function deleteListByID(userID, listID) {
    const res = await fetch(baseUrl + 'users/' + userID + '/lists/' + listID, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const json = await res.json();
    return json;
}

export async function getTasks(userID, listID) {
    const res = await fetch(baseUrl + 'users/' + userID + '/lists/' + listID + '/tasks/', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const json = await res.json();
    return json;
}

export async function postTasks(userID, listID, new_task) {
    const res = await fetch(baseUrl + 'users/' + userID + '/lists/' + listID + '/tasks/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(new_task)
    });
    const json = await res.json();
    return json;
}

export async function getTaskByID(userID, listID, taskID) {
    const res = await fetch(baseUrl + 'users/' + userID + '/lists/' + listID + '/tasks/' + taskID, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const json = await res.json();
    return json;
}

export async function patchTaskByID(userID, listID, taskID, new_task) {
    const res = await fetch(baseUrl + 'users/' + userID + '/lists/' + listID + '/tasks/' + taskID, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(new_task)
    });
    const json = await res.json();
    return json;
}

export async function deleteTaskByID(userID, listID, taskID) {
    const res = await fetch(baseUrl + 'users/' + userID + '/lists/' + listID + '/tasks/' + taskID, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const json = await res.json();
    return json;
}

export async function getMultiUser() {
    const res = await fetch(baseUrl + 'multiuser', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const json = await res.json();
    return json;
}

export async function getMaxIDs() {
    const res = await fetch(baseUrl + 'max_ids', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const json = await res.json();
    return json;
}
