<template>
        <header>
            <h1><i class="fas fa-thumbtack"></i> {{object.name}}</h1>
        </header>
        <ul>
            <li v-for="task in object.items" v-bind:key="task.taskID">
                <input v-if="task.done" type="checkbox" name={{task.taskID}} checked v-on:click="toggle(task)"/>
                <input v-else type="checkbox" name={{task.taskID}} v-on:click="toggle(task)"/>
                <label for={{task.taskID}}>{{task.name}}</label>
            </li>
        </ul>
        <div class="input-box">
            <input class="input-txt" type="text" name="" placeholder="Add Task" v-bind:id="object.listID"/>
            <a v-on:click="add_to_list()"><i class="fas fa-plus-square"></i></a>
        </div>
</template>

<script>
import * as api from '../api/api.js';

export default {
  name: 'ToDoList',
  props: [
      'userID',
      'object',
  ],
  methods: {
      async add_to_list(){
          let new_task = {};
          new_task.name = document.getElementById(JSON.stringify(this.object.listID)).value;
          document.getElementById(JSON.stringify(this.object.listID)).value = "";
          if(new_task.name === ""){
              new_task.name = "default";
          }
          new_task.done = false;
          let max_ids = await api.getMaxIDs()
          new_task.taskID = max_ids.taskID+1;
          let final_answer = await api.postTasks( this.userID, this.object.listID, new_task)
          this.$emit('taskPatched');
      },
      async toggle(task){
          let new_task = task;
          new_task.done = !task.done;
          let answer = await api.patchTaskByID(this.userID, this.object.listID, task.taskID, new_task);
          let list = await api.getListByID(this.userID, this.object.listID);
          let findUntoggled = list.items.find(obj => {return obj.done === false});
          if(findUntoggled === undefined){ this.remove() }
          this.$emit('taskPatched')
      },
      async remove(){
        let answer = await api.deleteListByID(this.userID, this.object.listID);
        this.$emit('taskPatched')
    },
    }
};
</script>

<style scoped>

.input-box{
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 23px;
}

header{
    text-align: center;
}

li{
    list-style: none;
    align-items: center;
    align-content: center;
    white-space: nowrap;
}

</style>
