<template>
    <div v-if="addUserPopup" class="modal-container">
        <div class="modal">
            <header>
                <h3>Add a new User:</h3>
            </header>
            <div class="input-box">
                <input type="text" placeholder="Select Username" id="username"/>
            </div>
            <div class="buttons">
                <button v-on:click="saveUser()" class="save">Yes</button>
                <button v-on:click="close()" class="close">No</button>
            </div>
        </div>
    </div>
    <div v-if="deleteUserPopup" class="modal-container">
        <div class="modal">
            <header>
                <h3>You are about to delete user {{user.user}}</h3>
            </header>
            <div class="buttons">
                <button v-on:click="deleteUser()" class="save">Yes</button>
                <button v-on:click="close()" class="close">No</button>
            </div>
        </div>
    </div>
    <div v-if="deleteListPopup.popup" class="modal-container">
        <div class="modal">
            <header>
                <h3>Are you sure you want to delete {{user.lists[deleteListPopup.id].name}}?</h3>
            </header>
            <div class="buttons">
                <button v-on:click="remove()" class="save">Yes</button>
                <button v-on:click="close()" class="close">No</button>
            </div>
        </div>
    </div>
    <div v-if="addListPopup" class="modal-container">
        <div class="modal">
            <header>
                <h3>Add a ToDo List :)</h3>
                <p>In this section you can create a ToDo-List in order to plan out your day more efficiently.</p>
            </header>
            <div class="input-box">
                <input type="text" placeholder="Add Title" id="title"/>
            </div>
            <ul>
                <div class="cover">
                    <li v-for="item in items" v-bind:key="item.taskID">
                            <p class="added-tasks">{{item.name}}</p>
                            <a class="choose" v-on:click="removeTask(item.taskID)">
                                <i class="fas fa-trash-alt"></i>
                                <i class="far fa-trash-alt"></i>
                            </a>
                    </li>
                </div>
                <li>
                    <div class="input-box">
                        <input class="input-txt" type="text" name="" placeholder="Add Task" id="newtask"/>
                        <a v-on:click="add_to_tasks()"><i class="fas fa-plus-square"></i></a>
                    </div>
                </li>
            </ul>
            <div class="buttons">
                <button v-on:click="save()" class="save">Submit</button>
                <button v-on:click="close()" class="close">Cancel</button>
            </div>
        </div>
    </div>
</template>

<script>
import * as api from '../api/api.js';

export default {
    name: 'Modal',
    props: ['addListPopup','deleteListPopup','addUserPopup', 'deleteUserPopup','user'],
    data(){
        return{
            items: [],
            lastIncrement: 1,
        };
    },
    methods: {
        //needs to be modified
        async add_to_tasks(){
            let new_item = {};
            new_item.name = document.getElementById('newtask').value;
            let max_ids = await api.getMaxIDs()
            new_item.taskID = max_ids.taskID+this.lastIncrement;
            this.lastIncrement += 1;
            new_item.done = false;
            if(new_item.name === "")
                  new_item.name = "default";
            this.items.push(new_item);
            document.getElementById('newtask').value = "";
        },
        close: function(){
            this.$emit('update:deleteUserPopup', false);
            this.$emit('update:addUserPopup', false);
            this.$emit('update:addListPopup', false);
            this.$emit('update:deleteListPopup', {popup: false, id: -1});
            this.$emit('update:editListPopup', {popup2: false, id: -1});
            this.items = [];
            this.lastIncrement = 1;
        },
        removeTask: function(id){
            this.items = this.items.filter(obj => obj.taskID !== id);
        },
        async save(){
            let new_list = {};
            new_list.name = document.getElementById('title').value;
            document.getElementById('title').value = "";
            if(new_list.name === "")
                  new_list.name = "default";
            let max_ids = await api.getMaxIDs();
            new_list.listID = max_ids.listID+1;
            new_list.items = [];
            let answer = await api.postList(this.user.userID, new_list);
            for(const item of this.items){
                let random  = await api.postTasks(this.user.userID, new_list.listID, item);
            }
            this.$emit('updatedDB');
            this.close();
        },
        async remove(){
            let answer = await api.deleteListByID(this.user.userID, this.deleteListPopup.id);
            this.$emit('updatedDB');
            this.close();
        },
        async saveUser(){
            let new_user = {};
            new_user.user = document.getElementById('username').value;
            document.getElementById('username').value = "";
            if(new_user.user === "")
                  new_user.user = "default";
            let userlist = await api.getUsers();
            new_user.userID = userlist.length;
            new_user.lists = [];
            let answer = await api.createUsers(new_user);
            this.$emit('updateUsers');
            this.close();
        },
        async deleteUser(){
            let answer = await api.deleteUserByID(this.user.userID);
            this.$emit('updateUsers');
            this.close();
        },
    }
}
</script>

<style scoped>
.modal-container{
    width: 100%;
    height: 100vh;
    z-index: 1;
    background-color: rgba(0, 0, 0, 0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    position: fixed;
    top: 0;
    left: 0;
    opacity: 0.9;
}

.modal{
    background-color: #fff;
    width: 40rem;
    padding: 30px 50px;
    border-radius: 5px;
    box-shadow: var(--shadow);
    text-align: center;
    overflow-y: scroll;
}

.modal .header{
    margin: 0;

}

.modal .p{
    opacity: 0.7;
    font-size: 14px;
}

.modal ul{
    list-style: none;
}

.input-box{
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 23px;
}
.modal .added-tasks{
    box-shadow: var(--shadow);
    text-align: center;
}

.modal .added-tasks i{
    margin-right: 0;
}

.cover li{
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
}

.cover li p{
    width: 90%;
}

.cover li i{
    font-size: 20px;
}

.choose:hover .fas,
.choose .far {
    display: none;
}
.choose:hover .far {
    display: inline;
}

.cover li:nth-child(even) p{
    background-color: var(--primary);
}


.buttons{
    display: flex;
    align-items: center;
    justify-content: center;
}

.buttons > button{
    margin: 0.5rem;
    box-shadow: var(--shadow);
    padding: 0.3rem;
    border-radius: 5px;
}

.buttons .save{
    background-color: #98fb98;
}

.buttons .close{
    background-color: #DB7093;
}

.input-box{
    margin-bottom: 20px;
}
</style>
