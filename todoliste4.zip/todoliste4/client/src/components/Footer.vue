<template>
    <footer>
        <p>ToDo Liste | Vorlesung WEB- und XML-Technologien | Sommersemester 2021 &copy;</p>
    </footer>
</template>

<script>
export default {
  name: 'Footer'
};
</script>

<style scoped>
footer{
        background: var(--dark);
        color: var(--light);
        text-align: right;
        padding: 0.5rem 0;
        position: sticky;
        top: 100%;
        width: 100%;
        height: 2.5rem;
}

@media screen and (max-width: 1500px) {
    footer{
            height: 2rem;
            position: relative;
            margin-top: -2rem;
    }
}

@media screen and (max-width: 700px) {
}

@media screen and (max-width: 500px) {
}
</style>
