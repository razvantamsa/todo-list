<template>
    <section class="main-area">

                <!-- Boxes -->
                <section class="boxes">
                    <div class="box" v-for="object in user.lists" v-bind:key="object.listID">
                        <!--edited a bit -->
                        <ToDoList v-bind:object="object" v-bind:userID="user.userID" v-model="object.items" @taskPatched = "getPatchedTask"/>
                        <div class="buttons">
                            <div class="button" v-on:click="remove(object.listID)">Delete</div>
                            <div class="button" v-on:click="clear(object.listID)">Clear</div>
                        </div>
                    </div>
                </section>
    </section>

</template>

<script>
import ToDoList from './ToDoList.vue';
import * as api from '../api/api.js';

export default {
  name: 'MainArea',
  components: {
      ToDoList
  },
  props:[
    'user',
  ],
  methods: {
      remove: function(listID){
          this.$emit('deleteListPopup', {popup: true, id: listID});
      },
      getPatchedTask: function () {
          this.$emit('updatedDB');
      },
      async clear(listID){
          for(const item of this.user.lists[listID].items){
              if(item.done === true){
                  let answer = await api.deleteTaskByID(this.user.userID, listID, item.taskID);
              }
          }
          this.getPatchedTask();
      },
  }
};
</script>

<style scoped>

.main-area{
    padding: 0.5rem;
    overflow: auto;
    height: 100%;

}

.boxes{
    display: flex;
    flex-wrap: wrap;
    align-items: flex-start;
    justify-content: center;
}

.boxes > .box{
    margin: 0.5rem;
}

.box{
    transition-duration: 0.5s;
    background: var(--primary);
    padding: 1.5rem 2rem;
    box-shadow: var(--shadow);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
}

.box:hover{
    background: #f0f0f0;
}

.button{
    transition-duration: 0.5s;
    background: var(--primary);
    box-shadow: var(--shadow);
    padding: 0.2rem 0.5rem;
    border-radius: 5px;
    margin-bottom: 1rem;
}

.button:hover{
    background: var(--shadow);
}

.buttons{
    display: flex;
    flex-wrap: wrap;
    align-items: flex-start;
    justify-content: center;
}

.buttons > .button{
    margin-left: 0.5rem;
}

@media screen and (max-width: 1000px) {
    .boxes{
        align-items: center;
        justify-content: center;
    }
}

</style>
