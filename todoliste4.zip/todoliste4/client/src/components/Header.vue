<template>
    <nav class="top-nav">
        <ul>
            <li>
                <div class="dropdown">
                    <p class="dropbtn"><i class="fas fa-users-cog"></i> User Management</p>
                    <div class="dropdown-content">
                        <a v-on:click="addUserPopup()"><i class="fas fa-user-plus"></i> New User</a>
                        <a v-on:click="deleteUserPopup()"><i class="fas fa-user-times"></i> Delete User</a>
                        <a v-on:click="listPopup()"><i class="far fa-calendar-plus"> New List </i></a>
                        <div class="dropdown2">
                            <a class="dropbtn2"><i class="fas fa-users-cog"></i> Select User</a>
                                <div class="dropdown-content2">
                                    <ul>
                                        <li v-for="item in listOfUsers" v-bind:key="item.userID">
                                            <a v-on:click="select(item.userID)">
                                                <div v-if="item.userID === selected" class="selected"><i class="fas fa-user"></i> {{ item.user }}</div>
                                                <div v-else><i class="fas fa-user"></i> {{ item.user }}</div>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                        </div>
                    </div>
                </div>
            </li>
            <li v-for="item in listOfUsers" v-bind:key="item.userID">
                <p v-if="item.userID === selected" class="selected"><i class="fas fa-user"></i>Current User: {{ item.user }}</p>
            </li>
        </ul>
    </nav>
</template>

<script>
export default {
    name: 'Header',
    props: ['listOfUsers'],
    data () {
        return {
            selected: 0,
            };
        },
    methods: {
        select: function (id) {
            this.selected = id;
            this.$emit('selected_userID', id);
        },
        listPopup: function(){
            this.$emit('addListPopup', true);
        },
        addUserPopup: function(){
            this.$emit('addUserPopup', true);
        },
        deleteUserPopup: function(){
            this.$emit('deleteUserPopup', true);
        }
    }
};
</script>

<style scoped>
.top-nav{
    top: 0;
    position: absolute;
    width: 100%;
    background-color: var(--dark);
}

.top-nav ul{
    padding: 0;
    list-style: none;
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-start;
    flex-direction: row;
    align-items: center;
}

.top-nav p{
    display: block;
    text-decoration: none;
    padding: 0.3rem 3rem;
    text-align: center;
    font-size: 0.9rem;
    box-shadow: var(--shadow);
    background: var(--dark);
    color: var(--primary);
}

.top-nav p:hover{
    background: var(--primary);
    color: var(--dark);
}

.top-nav .selected{
    background: var(--primary);
    color: var(--dark);
}

.dropbtn {
    text-decoration: none;
}

.dropdown {
    text-decoration: none;
    position: relative;
    display: inline-block;
}

.dropdown-content {
    text-decoration: none;
    display: none;
    position: absolute;
    z-index: 1;
}

.dropdown-content a {
    text-decoration: none;
    display: block;
    text-align: center;
    width: 200px;
    box-shadow: var(--shadow);
    background: var(--dark);
    color: var(--primary);
}

.dropdown-content a:hover {
    background: var(--primary);
    color: var(--dark);
}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {
    background: var(--primary);
    color: var(--dark);
}


.dropbtn2 {
    text-decoration: none;
}

.dropdown2 {
    text-decoration: none;
    position: relative;
    display: inline-block;
}

.dropdown-content2{
    margin-top:-40px;
    margin-left: 200px;
}

.dropdown-content2 {
    text-decoration: none;
    display: none;
    position: absolute;
    z-index: 1;
}

.dropdown-content2 a {
    text-decoration: none;
    display: block;
    text-align: center;
    width: 200px;
    box-shadow: var(--shadow);
    background: var(--dark);
    color: var(--primary);
}

.dropdown-content2 a:hover {
    background: var(--primary);
    color: var(--dark);
}

.dropdown2:hover .dropdown-content2 {
    display: flex;
    flex-wrap: wrap;
    align-content: stretch;
    flex-direction: column;
}

.dropdown2:hover .dropdown-content2 li {
    margin: 0;
}

.dropdown2:hover .dropdown-content2 > a{
    margin-bottom: 0;
    padding-bottom: 0
}

.dropdown2:hover .dropbtn {
    background: var(--primary);
    color: var(--dark);
}

@media screen and (max-width: 1200px) {

    .top-nav ul{
        flex-direction: column;
    }
}

@media screen and (max-width: 1000px) {

}

</style>
