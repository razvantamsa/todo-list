<template>
    <Header @selected_userID = "getUser" @addListPopup = "getAddListPopup" @addUserPopup = "getAddUserPopup" @deleteUserPopup = "getDeleteUserPopup" v-bind:listOfUsers="listOfUsers"/>
    <div class="wrapper">
        <Modal v-model:addListPopup.sync="addListPopup" v-model:deleteListPopup.sync="deleteListPopup" v-model:addUserPopup.sync="addUserPopup" v-model:deleteUserPopup.sync="deleteUserPopup" v-bind:user="user" @updatedDB = "getUpdatedDB" @updateUsers = "updateHeader"/>
        <MainArea v-bind:user="user" @deleteListPopup = "getDeleteListPopup" @updatedDB = "getUpdatedDB"/>
    </div>
    <Footer/>
</template>

<script>
import Header from './components/Header.vue';
import MainArea from './components/MainArea.vue';
import Footer from './components/Footer.vue';
import Modal from './components/Modal.vue';
import * as api from './api/api.js';

export default {
  name: 'App',
  components: {
      Header,
      MainArea,
      Footer,
      Modal
  },
  data: function() {
    return {
      user: {},
      listOfUsers: {},
      addListPopup: false,
      deleteListPopup: {popup: false, id:-1},
      addUserPopup: false,
      deleteUserPopup: false,
      reloadUsers: false,
    };
  },
  beforeMount(){
      this.loadPage(0);
  },
  methods: {
      async loadPage(value){
          this.user = await api.getUserByID(value);
          this.listOfUsers = await api.getUsers();
      },
      async getUser(value) {
          this.user = await api.getUserByID(value);
      },
      async getAddListPopup(popup_value) {
          this.addListPopup = popup_value;
      },
      async getAddUserPopup(popup_value) {
          this.addUserPopup = popup_value;
      },
      async getDeleteUserPopup(popup_value) {
          this.deleteUserPopup = popup_value;
      },
      getDeleteListPopup(popup_value){
          this.deleteListPopup = popup_value;
      },
      getUpdatedDB(){
          this.loadPage(this.user.userID);
      },
      async updateHeader(){
          this.listOfUsers = await api.getUsers();
      }
    }
};
</script>

<style>
:root{
    --primary: #ddd;
    --light: #fff;
    --dark: #333;
    --shadow: 0 1px 5px rgba(104, 104, 104, 0.8);
}

html{
    box-sizing: border-box;
    font-family: Arial, Helvetica, sans-serif;
    color: var(--dark);
    min-height: 100vh;
    padding: 0;
    margin: 0;
}

body{
    background: #ccc;
    line-height: 1.4;
    min-height: 100vh;
    padding: 0;
    margin: 0;
    padding-top: 15vh;
}

.btn{
    color: var(--dark);
    text-decoration: none;
    border: 0;
    font-size: 20px;
}

.wrapper{
    min-height: 100vh;
    position: relative;
}

@media screen and (max-width: 1200px) {
    body{
        padding-top: 20vh;
    }
}

@media screen and (max-width: 900px) {
    body{
        padding-top: 20vh;
    }
}

@media screen and (max-width: 700px) {
    body{
        padding-top: 20vh;
    }
}

</style>
