Aufgabe2: Sicherheitsabfrage, Mehrere Benutzer
Aufgabe3: Endpunkt /api/multiuser (GET), Endpunkt /api/max_ids (GET)
Zusätzlich habe ich hinzugefüfgt:
Clear (alle erledigte Aufgaben der entsprechenden Liste werden gelöscht)

npm install cors für die Server
